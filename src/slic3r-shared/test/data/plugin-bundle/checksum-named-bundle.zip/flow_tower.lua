-- Calibration patterns - flow_tower.lua
-- Demo plugin for the PrusaSlicer plugin marketplace prototype.
info = {
    id = "flow_tower",
    type = "project.plugin",
    title = "Calibration patterns",
    menu = "Marketplace demo/Calibration patterns",
    params = {
        {name = "count", label = "How many", type = "int", default = 1}
    }
}

function execute(params)
    print("Calibration patterns (flow_tower.lua) ran with count=" .. params.count)
end
