# Calibration patterns

# Calibration patterns

Generate flow towers, temperature towers and retraction tests directly inside PrusaSlicer. Adds calibration models to the plate and annotates each step.

- Flow tower with per-band flow ratios
- Temperature tower
- Retraction tuning helper
